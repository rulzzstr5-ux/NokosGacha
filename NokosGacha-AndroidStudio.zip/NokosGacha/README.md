# Nokos Gacha Android - Demo v1.0

Prototype Android Studio berbasis Java + WebView. Semua hasil gacha, saldo, dan riwayat masih simulasi lokal; belum terhubung ke supplier/API dan tidak menghasilkan nomor telepon aktif atau OTP.

## Membuka dan membuat APK
1. Ekstrak folder `NokosGacha`.
2. Buka folder tersebut melalui Android Studio (`Open`).
3. Tunggu Gradle Sync selesai (perlu internet untuk mengunduh Android Gradle Plugin dan Android SDK yang sesuai).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android: 6.0 (API 23). Compile/target SDK: 35.
